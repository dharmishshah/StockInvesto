package stocks.model.stock;

/**
 * A transaction can be either buying or selling the stock.
 */
enum TransactionType {
  Buy, Sell
}
