package stocks.view.portfolio;

import java.awt.event.ActionListener;
import java.util.Map;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import stocks.controller.GUIController;
import stocks.view.GUIView;

/**
 * The following class represents the Portfolio view panel.
 */
public class PortfolioView extends javax.swing.JPanel implements GUIView {

  GUIController controller;
  private javax.swing.JTextField PVDateTxt;
  private javax.swing.JLabel PVErrorLbl;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JLabel jLabel2;
  private javax.swing.JScrollPane jScrollPane1;
  private javax.swing.JScrollPane jScrollPane2;
  private javax.swing.JTable jTable1;
  private javax.swing.JTable jTable2;
  private javax.swing.JButton summaryViewBtn;
  /**
   * Creates new form PortfolioView
   *
   * @param controller the GUIController object.
   */
  public PortfolioView(GUIController controller) {
    initComponents();
    controller.setPortfolioDisplayView(this);
    summaryViewBtn.setActionCommand("viewPortfolio");
  }

  /**
   * This method is called from within the constructor to initialize the form.
   */
  @SuppressWarnings("unchecked")
  private void initComponents() {

    jScrollPane2 = new javax.swing.JScrollPane();
    jTable2 = new javax.swing.JTable();
    jLabel1 = new javax.swing.JLabel();
    summaryViewBtn = new javax.swing.JButton();
    jLabel2 = new javax.swing.JLabel();
    PVDateTxt = new javax.swing.JTextField();
    jScrollPane1 = new javax.swing.JScrollPane();
    jTable1 = new javax.swing.JTable();
    PVErrorLbl = new javax.swing.JLabel();

    jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object[][]{
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null}
            },
            new String[]{
                    "Title 1", "Title 2", "Title 3", "Title 4"
            }
    ));
    jScrollPane2.setViewportView(jTable2);

    jLabel1.setText("Summary");

    summaryViewBtn.setText("View");
    summaryViewBtn.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        summaryViewBtnActionPerformed(evt);
      }
    });

    jLabel2.setText("ENTER DATE(MM/DD/YYYY)");

    jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object[][]{
                    {},
                    {},
                    {},
                    {}
            },
            new String[]{

            }
    ));
    jScrollPane1.setViewportView(jTable1);

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
    this.setLayout(layout);
    layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                            .addContainerGap()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout
                                    .Alignment.LEADING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout
                                            .DEFAULT_SIZE, 474, Short.MAX_VALUE)
                                    .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup
                                                    (javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(PVErrorLbl)
                                                    .addGroup(layout.createSequentialGroup()
                                                            .addGroup(layout.createParallelGroup
                                                                    (javax.swing.GroupLayout
                                                                                    .Alignment.LEADING,
                                                                            false)
                                                                    .addComponent(jLabel1)
                                                                    .addComponent(jLabel2,
                                                                            javax.swing.GroupLayout
                                                                                    .DEFAULT_SIZE,
                                                                            javax.swing.GroupLayout
                                                                                    .DEFAULT_SIZE,
                                                                            Short.MAX_VALUE)
                                                                    .addComponent(PVDateTxt))
                                                            .addGap(18, 18, 18)
                                                            .addComponent(summaryViewBtn,
                                                                    javax.swing.GroupLayout
                                                                            .PREFERRED_SIZE,
                                                                    131, javax.swing
                                                                            .GroupLayout
                                                                            .PREFERRED_SIZE)))
                                            .addGap(0, 0, Short.MAX_VALUE)))
                            .addContainerGap())
    );
    layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout
                                    .Alignment.BASELINE)
                                    .addComponent(PVDateTxt, javax.swing.GroupLayout.PREFERRED_SIZE,
                                            javax.swing.GroupLayout.DEFAULT_SIZE,
                                            javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(summaryViewBtn))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE,
                                    227, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(PVErrorLbl)
                            .addContainerGap(26, Short.MAX_VALUE))
    );
  }

  private void summaryViewBtnActionPerformed(java.awt.event.ActionEvent evt) {
  }

  /**
   * The following method displays the stock data.
   *
   * @param data the stock data to be displayed.
   */
  public void setSummaryData(Map<String, Map<String, Double>> data) {
    String[] columns = new String[]{
            "Portfolio Id", "Portfolio Name", "Stock Cost Basis", "Stock Value",
            "Volume", "Commission"
    };

    //actual data for the table in a 2d array
    Object[][] dataTable = new Object[data != null ? data.size() : 0][6];
    if (data != null) {
      int i = 0;
      int j = 0;
      for (Map.Entry<String, Map<String, Double>> entry : data.entrySet()) {
        String tickerSymbol = entry.getKey();


        Map<String, Double> values = entry.getValue();
        Double costBasis = values.get("costBasis");
        Double valueBasis = values.get("totalValue");
        Double volume = values.get("volume");
        Double commissionRate = values.get("commission");

        dataTable[i][0] = i + 1;
        dataTable[i][1] = tickerSymbol;
        dataTable[i][2] = costBasis;
        dataTable[i][3] = valueBasis;
        dataTable[i][4] = volume;
        dataTable[i][5] = commissionRate;
        i++;

      }
    }
    //create table with data
    JTable table = new JTable(dataTable, columns);
    table.setVisible(true);
    TableModel tm = new DefaultTableModel(dataTable, columns);
    jScrollPane1.setViewportView(new JTable(tm));

  }

  /**
   * The following method executes the button action.
   *
   * @param listener the ActionListener object.
   */
  public void addActionListener(ActionListener listener) {
    summaryViewBtn.addActionListener(listener);
  }
}
